#include <iostream>
using namespace std;
#include "UI/UI.h"
#include "Data_Structures/Priority_Queue.h"


int main()
{

	// CREATE OBJECT //
	UI program;


	// Start the Interface //
	program.Start();

}


