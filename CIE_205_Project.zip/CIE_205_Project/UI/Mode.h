#pragma once

#ifndef _MODE_
#define _MODE_


enum Mode
{
	INTERACTIVE = 1,
	STEP = 2,
	SILENT = 3
};


#endif