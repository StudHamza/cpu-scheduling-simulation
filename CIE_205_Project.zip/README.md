# cpu-scheduling-simulation

*Scheduler* *FCFS* *SJF* *EDF* *RR*

## A cmd Utility for a cpu scheduler


**Noting yet**

